import { useState, useEffect } from "react";
import { TopicSelector } from "./components/TopicSelector";
import { WorksheetView } from "./components/WorksheetView";
import { StepSolver } from "./components/StepSolver";
import { AIChatbot } from "./components/AIChatbot";
import { FormulaSheet } from "./components/FormulaSheet";
import { getProblemsByTopic, mathTopics, MathProblem } from "./data/mathProblems";
import { getPhysicsProblemsByTopic, physicsTopics } from "./data/physicsProblems";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Calculator, Atom, ArrowLeft } from "lucide-react";
import { loadProgress, clearProgress } from "./utils/localStorageHelper";

type AppState = "topics" | "worksheet" | "solving";
type Subject = "maths" | "physics";

function App() {
  const [appState, setAppState] = useState<AppState>("topics");
  const [subject, setSubject] = useState<Subject>("maths");
  const [selectedTopic, setSelectedTopic] = useState<string>("");
  const [currentProblem, setCurrentProblem] = useState<MathProblem | null>(null);
  const [completedProblems, setCompletedProblems] = useState<Set<string>>(new Set());

  // Load progress on mount
  useEffect(() => {
    const saved = loadProgress();
    setCompletedProblems(new Set(saved.completedProblems));
  }, []);

  const handleSelectTopic = (topic: string) => {
    setSelectedTopic(topic);
    setAppState("worksheet");
  };

  const handleSelectProblem = (problem: MathProblem) => {
    setCurrentProblem(problem);
    setAppState("solving");
  };

  const handleCompleteProblem = () => {
    if (currentProblem) {
      setCompletedProblems(prev => new Set([...prev, currentProblem.id]));
    }
    setAppState("worksheet");
    setCurrentProblem(null);
  };

  const handleBackToTopics = () => {
    setAppState("topics");
    setSelectedTopic("");
    setCurrentProblem(null);
  };

  const handleBackToWorksheet = () => {
    setAppState("worksheet");
    setCurrentProblem(null);
  };

  const getProblems = () => {
    return subject === "maths" 
      ? getProblemsByTopic(selectedTopic) 
      : getPhysicsProblemsByTopic(selectedTopic);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800">
      {/* Header / Navigation */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">
              M
            </div>
            <span className="font-bold text-xl text-slate-800">MathStep</span>
          </div>

          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-lg">
            <Button
              variant={subject === "maths" ? "default" : "ghost"}
              size="sm"
              onClick={() => { setSubject("maths"); setAppState("topics"); setSelectedTopic(""); }}
              className={subject === "maths" ? "bg-white shadow-sm text-slate-800" : "text-slate-600"}
            >
              <Calculator className="w-4 h-4 mr-2" />
              Maths
            </Button>
            <Button
              variant={subject === "physics" ? "default" : "ghost"}
              size="sm"
              onClick={() => { setSubject("physics"); setAppState("topics"); setSelectedTopic(""); }}
              className={subject === "physics" ? "bg-white shadow-sm text-slate-800" : "text-slate-600"}
            >
              <Atom className="w-4 h-4 mr-2" />
              Physics
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="py-8">
        {appState === "topics" && (
          <TopicSelector
            subject={subject}
            topics={subject === "maths" ? mathTopics : physicsTopics}
            onSelectTopic={handleSelectTopic}
          />
        )}

        {appState === "worksheet" && (
          <WorksheetView
            topic={selectedTopic}
            problems={getProblems()}
            completedIds={completedProblems}
            onSelectProblem={handleSelectProblem}
            onBack={handleBackToTopics}
          />
        )}

        {appState === "solving" && currentProblem && (
          <StepSolver
            problem={currentProblem}
            onBack={handleBackToWorksheet}
            onComplete={handleCompleteProblem}
          />
        )}
      </main>

      {/* Global Widgets */}
      <AIChatbot />
      <FormulaSheet />
    </div>
  );
}

export default App;