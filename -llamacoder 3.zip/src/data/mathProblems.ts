export interface MathStep {
  explanation: string;
  equation: string;
  highlight: string[];
  action: string;
}

export interface MathProblem {
  id: string;
  topic: string;
  difficulty: "★☆☆" | "★★☆" | "★★★";
  question: string;
  steps: MathStep[];
}

export const mathTopics = [
  "Solving Quadratic Equations",
  "Simultaneous Equations",
  "Trigonometry",
  "Probability Trees",
  "Circle Theorems",
  "Vectors",
  "Indices & Surds",
  "Algebraic Fractions",
  "Graph Transformations",
  "Pythagoras Theorem",
  "Standard Form",
  "Ratio & Proportion"
];

export const mathProblems: MathProblem[] = [
  // --- Quadratic Equations ---
  {
    id: "quad1",
    topic: "Solving Quadratic Equations",
    difficulty: "★★☆",
    question: "Solve: (x + 3)(x - 2) = 0",
    steps: [
      { explanation: "Set each factor equal to zero", equation: "(x + 3) = 0  and  (x - 2) = 0", highlight: ["(x + 3)", "(x - 2)"], action: "Zero Product Property" },
      { explanation: "Solve the first equation for x", equation: "x + 3 = 0  →  x = -3", highlight: ["x = -3"], action: "Solve first equation" },
      { explanation: "Solve the second equation for x", equation: "x - 2 = 0  →  x = 2", highlight: ["x = 2"], action: "Solve second equation" },
      { explanation: "Combine both solutions", equation: "x = -3  or  x = 2", highlight: ["x = -3", "x = 2"], action: "Final solution" }
    ]
  },
  {
    id: "quad2",
    topic: "Solving Quadratic Equations",
    difficulty: "★☆☆",
    question: "Solve: x² - 9 = 0",
    steps: [
      { explanation: "Recognize difference of squares", equation: "x² - 9 = (x + 3)(x - 3)", highlight: ["(x + 3)(x - 3)"], action: "Factorise" },
      { explanation: "Set factors to zero", equation: "x + 3 = 0  or  x - 3 = 0", highlight: ["x + 3", "x - 3"], action: "Zero Product Property" },
      { explanation: "Solve for x", equation: "x = -3  or  x = 3", highlight: ["x = -3", "x = 3"], action: "Final solution" }
    ]
  },
  {
    id: "quad3",
    topic: "Solving Quadratic Equations",
    difficulty: "★★★",
    question: "Solve: x² - 5x + 6 = 0",
    steps: [
      { explanation: "Find two numbers that multiply to 6 and add to -5", equation: "-2 and -3", highlight: ["-2", "-3"], action: "Find factors" },
      { explanation: "Factorise the quadratic", equation: "(x - 2)(x - 3) = 0", highlight: ["(x - 2)(x - 3)"], action: "Factorise" },
      { explanation: "Set each factor to zero", equation: "x - 2 = 0  or  x - 3 = 0", highlight: ["x - 2", "x - 3"], action: "Zero Product Property" },
      { explanation: "Solve for x", equation: "x = 2  or  x = 3", highlight: ["x = 2", "x = 3"], action: "Final solution" }
    ]
  },

  // --- Simultaneous Equations ---
  {
    id: "sim1",
    topic: "Simultaneous Equations",
    difficulty: "★☆☆",
    question: "Solve: 2x + y = 10 and x - y = 2",
    steps: [
      { explanation: "Add the two equations together to eliminate y", equation: "(2x + y) + (x - y) = 10 + 2", highlight: ["y", "-y"], action: "Elimination method" },
      { explanation: "Simplify and solve for x", equation: "3x = 12  →  x = 4", highlight: ["x = 4"], action: "Solve for x" },
      { explanation: "Substitute x = 4 back into the first equation", equation: "2(4) + y = 10", highlight: ["4"], action: "Substitution" },
      { explanation: "Simplify and solve for y", equation: "8 + y = 10  →  y = 2", highlight: ["y = 2"], action: "Solve for y" },
      { explanation: "State the final solution pair", equation: "x = 4,  y = 2", highlight: ["x = 4", "y = 2"], action: "Final solution" }
    ]
  },
  {
    id: "sim2",
    topic: "Simultaneous Equations",
    difficulty: "★★☆",
    question: "Solve: y = 2x + 1 and y = 3x - 2",
    steps: [
      { explanation: "Set the expressions for y equal to each other", equation: "2x + 1 = 3x - 2", highlight: ["2x + 1", "3x - 2"], action: "Equate" },
      { explanation: "Rearrange to solve for x", equation: "1 + 2 = 3x - 2x  →  3 = x", highlight: ["x = 3"], action: "Solve for x" },
      { explanation: "Substitute x = 3 into first equation", equation: "y = 2(3) + 1", highlight: ["3"], action: "Substitution" },
      { explanation: "Calculate y", equation: "y = 6 + 1 = 7", highlight: ["y = 7"], action: "Calculate y" },
      { explanation: "Final answer", equation: "x = 3,  y = 7", highlight: ["x = 3", "y = 7"], action: "Final solution" }
    ]
  },

  // --- Trigonometry ---
  {
    id: "trig1",
    topic: "Trigonometry",
    difficulty: "★★☆",
    question: "Find angle x: opposite = 5, hypotenuse = 10",
    steps: [
      { explanation: "Identify the known sides: opposite and hypotenuse", equation: "Opposite = 5,  Hypotenuse = 10", highlight: ["Opposite", "Hypotenuse"], action: "Label the triangle" },
      { explanation: "Choose the correct trigonometric ratio (SOHCAHTOA)", equation: "sin(x) = opposite / hypotenuse", highlight: ["sin(x)", "opposite / hypotenuse"], action: "Choose formula" },
      { explanation: "Substitute the values and calculate", equation: "sin(x) = 5/10 = 0.5", highlight: ["0.5"], action: "Calculate ratio" },
      { explanation: "Use inverse sine to find the angle", equation: "x = sin⁻¹(0.5) = 30°", highlight: ["30°"], action: "Inverse sine" },
      { explanation: "Final answer", equation: "x = 30°", highlight: ["30°"], action: "Final answer" }
    ]
  },
  {
    id: "trig2",
    topic: "Trigonometry",
    difficulty: "★★★",
    question: "Find side x: angle = 60°, hypotenuse = 10",
    steps: [
      { explanation: "Identify sides: adjacent (x) and hypotenuse (10)", equation: "Adjacent = x,  Hypotenuse = 10", highlight: ["Adjacent", "Hypotenuse"], action: "Label the triangle" },
      { explanation: "Choose the correct ratio (CAH)", equation: "cos(60°) = adjacent / hypotenuse", highlight: ["cos(60°)"], action: "Choose formula" },
      { explanation: "Substitute known values", equation: "0.5 = x / 10", highlight: ["0.5", "x / 10"], action: "Substitute" },
      { explanation: "Solve for x", equation: "x = 0.5 × 10 = 5", highlight: ["x = 5"], action: "Calculate" },
      { explanation: "Final answer", equation: "x = 5", highlight: ["5"], action: "Final answer" }
    ]
  },

  // --- Probability Trees ---
  {
    id: "prob1",
    topic: "Probability Trees",
    difficulty: "★☆☆",
    question: "Coin tossed twice. Find P(Heads, Heads)",
    steps: [
      { explanation: "First toss: probability of Heads or Tails", equation: "P(H) = 1/2,  P(T) = 1/2", highlight: ["1/2"], action: "First branch" },
      { explanation: "Second toss: probability remains the same", equation: "P(H) = 1/2,  P(T) = 1/2", highlight: ["1/2"], action: "Second branch" },
      { explanation: "Follow the path: Heads then Heads", equation: "Path: H → H", highlight: ["H", "H"], action: "Trace path" },
      { explanation: "Multiply probabilities along the path", equation: "P(H,H) = 1/2 × 1/2 = 1/4", highlight: ["1/4"], action: "Calculate" },
      { explanation: "Final probability", equation: "P(Heads, Heads) = 1/4", highlight: ["1/4"], action: "Final answer" }
    ]
  },

  // --- Circle Theorems ---
  {
    id: "circle1",
    topic: "Circle Theorems",
    difficulty: "★★★",
    question: "Find angle x: angle in semicircle is 90°",
    steps: [
      { explanation: "Identify that the triangle is in a semicircle", equation: "Triangle is inscribed in a semicircle", highlight: ["semicircle"], action: "Theorem recognition" },
      { explanation: "Apply the theorem: angle in a semicircle is 90°", equation: "Angle at circumference = 90°", highlight: ["90°"], action: "Apply theorem" },
      { explanation: "Calculate x using the given angle", equation: "x = 90° - 35°", highlight: ["x = 90° - 35°"], action: "Calculate" },
      { explanation: "Final answer", equation: "x = 55°", highlight: ["55°"], action: "Final answer" }
    ]
  },

  // --- Vectors ---
  {
    id: "vector1",
    topic: "Vectors",
    difficulty: "★★☆",
    question: "Given a = (2,3) and b = (1,-1), find 2a + b",
    steps: [
      { explanation: "Multiply vector a by the scalar 2", equation: "2a = 2 × (2,3) = (4,6)", highlight: ["(4,6)"], action: "Scalar multiplication" },
      { explanation: "Add vector b to the result", equation: "(4,6) + (1,-1)", highlight: ["(4,6)", "(1,-1)"], action: "Vector addition" },
      { explanation: "Add the x-components together", equation: "x: 4 + 1 = 5", highlight: ["5"], action: "X component" },
      { explanation: "Add the y-components together", equation: "y: 6 + (-1) = 5", highlight: ["5"], action: "Y component" },
      { explanation: "Final vector result", equation: "2a + b = (5,5)", highlight: ["(5,5)"], action: "Final answer" }
    ]
  },

  // --- Indices & Surds ---
  {
    id: "indices1",
    topic: "Indices & Surds",
    difficulty: "★★☆",
    question: "Simplify: x³ × x⁵",
    steps: [
      { explanation: "Identify the rule for multiplying powers with the same base", equation: "Rule: xᵃ × xᵇ = xᵃ⁺ᵇ", highlight: ["xᵃ × xᵇ = xᵃ⁺ᵇ"], action: "Index rule" },
      { explanation: "Add the exponents", equation: "3 + 5 = 8", highlight: ["8"], action: "Add exponents" },
      { explanation: "Write the simplified form", equation: "x³ × x⁵ = x⁸", highlight: ["x⁸"], action: "Final answer" }
    ]
  },

  // --- Algebraic Fractions ---
  {
    id: "frac1",
    topic: "Algebraic Fractions",
    difficulty: "★★★",
    question: "Simplify: (x² - 4) / (x + 2)",
    steps: [
      { explanation: "Factorise the numerator using difference of squares", equation: "x² - 4 = (x + 2)(x - 2)", highlight: ["(x + 2)(x - 2)"], action: "Difference of squares" },
      { explanation: "Rewrite the fraction with the factorised numerator", equation: "(x + 2)(x - 2) / (x + 2)", highlight: ["(x + 2)(x - 2)", "(x + 2)"], action: "Rewrite" },
      { explanation: "Cancel the common factor (x + 2)", equation: "= (x - 2)", highlight: ["(x - 2)"], action: "Cancel" },
      { explanation: "Final simplified answer", equation: "Answer: x - 2", highlight: ["x - 2"], action: "Final answer" }
    ]
  },

  // --- Graph Transformations ---
  {
    id: "graph1",
    topic: "Graph Transformations",
    difficulty: "★★☆",
    question: "Describe transformation: y = f(x) → y = f(x) + 3",
    steps: [
      { explanation: "Identify where the change occurs in the function", equation: "Change: +3 (outside the brackets)", highlight: ["+3"], action: "Analyze" },
      { explanation: "Determine the type of transformation", equation: "Outside = Vertical transformation", highlight: ["Vertical"], action: "Type" },
      { explanation: "Determine the direction", equation: "Positive = Upward movement", highlight: ["Upward"], action: "Direction" },
      { explanation: "Final description", equation: "Translation 3 units up", highlight: ["Translation 3 units up"], action: "Final answer" }
    ]
  },

  // --- Pythagoras Theorem ---
  {
    id: "pyth1",
    topic: "Pythagoras Theorem",
    difficulty: "★☆☆",
    question: "Find hypotenuse: a = 3, b = 4",
    steps: [
      { explanation: "Write down Pythagoras' theorem", equation: "c² = a² + b²", highlight: ["c² = a² + b²"], action: "Formula" },
      { explanation: "Substitute the known values", equation: "c² = 3² + 4² = 9 + 16 = 25", highlight: ["25"], action: "Substitute" },
      { explanation: "Square root to find c", equation: "c = √25 = 5", highlight: ["5"], action: "Solve" },
      { explanation: "Final answer", equation: "Hypotenuse = 5", highlight: ["5"], action: "Final answer" }
    ]
  },

  // --- Standard Form ---
  {
    id: "std1",
    topic: "Standard Form",
    difficulty: "★☆☆",
    question: "Write 4500 in standard form",
    steps: [
      { explanation: "Move decimal point to get a number between 1 and 10", equation: "4500 → 4.5", highlight: ["4.5"], action: "Position decimal" },
      { explanation: "Count how many places the decimal moved", equation: "Moved 3 places to the left", highlight: ["3"], action: "Count moves" },
      { explanation: "Write in standard form", equation: "4.5 × 10³", highlight: ["4.5 × 10³"], action: "Final answer" }
    ]
  },

  // --- Ratio & Proportion ---
  {
    id: "ratio1",
    topic: "Ratio & Proportion",
    difficulty: "★☆☆",
    question: "Divide £60 in ratio 2:3",
    steps: [
      { explanation: "Add the parts of the ratio to find total parts", equation: "Total parts = 2 + 3 = 5", highlight: ["5"], action: "Total parts" },
      { explanation: "Find the value of one part", equation: "One part = £60 ÷ 5 = £12", highlight: ["£12"], action: "One part" },
      { explanation: "Calculate the first share", equation: "First share = 2 × £12 = £24", highlight: ["£24"], action: "First share" },
      { explanation: "Calculate the second share", equation: "Second share = 3 × £12 = £36", highlight: ["£36"], action: "Second share" },
      { explanation: "Final answer", equation: "£24 and £36", highlight: ["£24", "£36"], action: "Final answer" }
    ]
  }
];

export function getProblemsByTopic(topic: string): MathProblem[] {
  return mathProblems.filter(p => p.topic === topic);
}

export function getProblemById(id: string): MathProblem | undefined {
  return mathProblems.find(p => p.id === id);
}