import { MathStep, MathProblem } from "./mathProblems";

export const physicsTopics = [
  "Forces & Motion",
  "Energy Resources",
  "Electricity",
  "Waves",
  "Magnetism",
  "Particle Model"
];

export const physicsProblems: MathProblem[] = [
  {
    id: "phys1",
    topic: "Forces & Motion",
    difficulty: "★☆☆",
    question: "Calculate force: mass = 5kg, acceleration = 2m/s²",
    steps: [
      { explanation: "Identify the formula for Force", equation: "F = m × a", highlight: ["F = m × a"], action: "Newton's Second Law" },
      { explanation: "Substitute the values", equation: "F = 5 × 2", highlight: ["5", "2"], action: "Substitution" },
      { explanation: "Calculate the result", equation: "F = 10 N", highlight: ["10 N"], action: "Calculate" }
    ]
  },
  {
    id: "phys2",
    topic: "Forces & Motion",
    difficulty: "★★☆",
    question: "Calculate weight: mass = 50kg, g = 10N/kg",
    steps: [
      { explanation: "Identify the formula for Weight", equation: "W = m × g", highlight: ["W = m × g"], action: "Gravity formula" },
      { explanation: "Substitute the values", equation: "W = 50 × 10", highlight: ["50", "10"], action: "Substitution" },
      { explanation: "Calculate the result", equation: "W = 500 N", highlight: ["500 N"], action: "Calculate" }
    ]
  },
  {
    id: "phys3",
    topic: "Energy Resources",
    difficulty: "★☆☆",
    question: "Calculate KE: mass = 10kg, velocity = 5m/s",
    steps: [
      { explanation: "Identify the formula for Kinetic Energy", equation: "KE = 0.5 × m × v²", highlight: ["KE = 0.5 × m × v²"], action: "KE Formula" },
      { explanation: "Substitute the values", equation: "KE = 0.5 × 10 × 5²", highlight: ["0.5", "10", "5"], action: "Substitution" },
      { explanation: "Square the velocity", equation: "KE = 0.5 × 10 × 25", highlight: ["25"], action: "Square" },
      { explanation: "Calculate the result", equation: "KE = 125 J", highlight: ["125 J"], action: "Calculate" }
    ]
  },
  {
    id: "phys4",
    topic: "Electricity",
    difficulty: "★☆☆",
    question: "Calculate Voltage: Current = 2A, Resistance = 10Ω",
    steps: [
      { explanation: "Identify the formula for Voltage", equation: "V = I × R", highlight: ["V = I × R"], action: "Ohm's Law" },
      { explanation: "Substitute the values", equation: "V = 2 × 10", highlight: ["2", "10"], action: "Substitution" },
      { explanation: "Calculate the result", equation: "V = 20 V", highlight: ["20 V"], action: "Calculate" }
    ]
  },
  {
    id: "phys5",
    topic: "Waves",
    difficulty: "★★☆",
    question: "Calculate Wave Speed: frequency = 50Hz, wavelength = 2m",
    steps: [
      { explanation: "Identify the wave equation", equation: "v = f × λ", highlight: ["v = f × λ"], action: "Wave Equation" },
      { explanation: "Substitute the values", equation: "v = 50 × 2", highlight: ["50", "2"], action: "Substitution" },
      { explanation: "Calculate the result", equation: "v = 100 m/s", highlight: ["100 m/s"], action: "Calculate" }
    ]
  }
];

export function getPhysicsProblemsByTopic(topic: string): MathProblem[] {
  return physicsProblems.filter(p => p.topic === topic);
}