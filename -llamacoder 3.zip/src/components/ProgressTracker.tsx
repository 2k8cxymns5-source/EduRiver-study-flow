import { CheckCircle } from "lucide-react";

interface ProgressTrackerProps {
  totalSteps: number;
  currentStep: number;
}

export function ProgressTracker({ totalSteps, currentStep }: ProgressTrackerProps) {
  return (
    <div className="flex items-center justify-center gap-2 mb-6">
      {Array.from({ length: totalSteps }).map((_, index) => (
        <div
          key={index}
          className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
            index < currentStep
              ? "bg-emerald-500 text-white"
              : "bg-slate-200 text-slate-400"
          }`}
        >
          {index < currentStep ? (
            <CheckCircle className="w-5 h-5" />
          ) : (
            <span className="text-sm font-medium">{index + 1}</span>
          )}
        </div>
      ))}
      <span className="ml-4 text-sm font-medium text-slate-600">
        {currentStep} of {totalSteps} steps
      </span>
    </div>
  );
}