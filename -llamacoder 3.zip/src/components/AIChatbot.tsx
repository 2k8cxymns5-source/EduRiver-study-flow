import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { MessageCircle, X, Send, Bot } from "lucide-react";

export function AIChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: "user" | "bot"; text: string }[]>([
    { role: "bot", text: "Hi! I'm your study buddy. Ask me about formulas, topics, or for a hint!" }
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;

    const userMsg = input.trim();
    setMessages(prev => [...prev, { role: "user", text: userMsg }]);
    setInput("");

    // Simple AI Logic (Simulated)
    setTimeout(() => {
      let botResponse = "I'm not sure about that. Try asking about 'quadratics', 'forces', or 'help'.";
      const lowerInput = userMsg.toLowerCase();

      if (lowerInput.includes("quadratic") || lowerInput.includes("factorise")) {
        botResponse = "For quadratics, try to factorise first! Look for two numbers that multiply to c and add to b.";
      } else if (lowerInput.includes("force") || lowerInput.includes("f=ma")) {
        botResponse = "Remember Newton's Second Law: Force = Mass × Acceleration (F=ma).";
      } else if (lowerInput.includes("energy") || lowerInput.includes("ke")) {
        botResponse = "Kinetic Energy is ½ × mass × velocity². Don't forget to square the velocity!";
      } else if (lowerInput.includes("trig") || lowerInput.includes("sohcahtoa")) {
        botResponse = "SOHCAHTOA: Sin=Opp/Hyp, Cos=Adj/Hyp, Tan=Opp/Adj.";
      } else if (lowerInput.includes("help") || lowerInput.includes("stuck")) {
        botResponse = "Take a deep breath! Break the problem down into smaller steps. What is the question asking for?";
      } else if (lowerInput.includes("hello") || lowerInput.includes("hi")) {
        botResponse = "Hello! Ready to solve some problems?";
      }

      setMessages(prev => [...prev, { role: "bot", text: botResponse }]);
    }, 600);
  };

  return (
    <>
      {/* Toggle Button */}
      {!isOpen && (
        <Button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-lg bg-indigo-600 hover:bg-indigo-700 text-white z-50 flex items-center justify-center"
        >
          <MessageCircle className="w-6 h-6" />
        </Button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 w-80 md:w-96 bg-white rounded-xl shadow-2xl border border-slate-200 z-50 flex flex-col overflow-hidden transition-all duration-300">
          <CardHeader className="bg-indigo-600 text-white p-4 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Bot className="w-4 h-4" />
              Study Buddy
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-indigo-700 h-8 w-8 p-0"
              onClick={() => setIsOpen(false)}
            >
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>
          
          <CardContent className="p-0 flex flex-col h-80">
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                      msg.role === "user"
                        ? "bg-indigo-600 text-white rounded-br-none"
                        : "bg-slate-100 text-slate-800 rounded-bl-none"
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-3 border-t border-slate-100 bg-slate-50">
              <div className="flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  placeholder="Ask a question..."
                  className="flex-1 h-9 text-sm"
                />
                <Button
                  onClick={handleSend}
                  size="sm"
                  className="h-9 px-3 bg-indigo-600 hover:bg-indigo-700"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </div>
      )}
    </>
  );
}