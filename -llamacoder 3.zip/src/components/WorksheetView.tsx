import { MathProblem } from "../data/mathProblems";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { CheckCircle, Circle, ArrowLeft, BookOpen } from "lucide-react";

interface WorksheetViewProps {
  topic: string;
  problems: MathProblem[];
  completedIds: Set<string>;
  onSelectProblem: (problem: MathProblem) => void;
  onBack: () => void;
}

export function WorksheetView({ topic, problems, completedIds, onSelectProblem, onBack }: WorksheetViewProps) {
  const completedCount = problems.filter(p => completedIds.has(p.id)).length;
  const isWorksheetComplete = completedCount === problems.length;

  const getDifficultyColor = (diff: string) => {
    if (diff === "★☆☆") return "text-emerald-600 bg-emerald-50 border-emerald-200";
    if (diff === "★★☆") return "text-amber-600 bg-amber-50 border-amber-200";
    return "text-rose-600 bg-rose-50 border-rose-200";
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-8">
      <div className="flex items-center gap-4 mb-6">
        <Button
          onClick={onBack}
          variant="ghost"
          size="sm"
          className="text-slate-600 hover:text-slate-800 hover:bg-slate-100"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          All Topics
        </Button>
      </div>

      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-2 flex items-center gap-3">
          <BookOpen className="w-8 h-8 text-sky-600" />
          {topic}
        </h1>
        <p className="text-slate-600">
          Complete the problems below to master this topic.
        </p>
      </div>

      <Card className={`mb-8 border-2 ${isWorksheetComplete ? "border-emerald-300 bg-emerald-50" : "border-slate-200"}`}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500 uppercase tracking-wide mb-1">Worksheet Progress</p>
              <p className="text-2xl font-bold text-slate-800">
                {completedCount} / {problems.length} Problems
              </p>
            </div>
            <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
              isWorksheetComplete ? "bg-emerald-500" : "bg-slate-200"
            }`}>
              {isWorksheetComplete ? (
                <CheckCircle className="w-8 h-8 text-white" />
              ) : (
                <span className="text-xl font-bold text-slate-500">{Math.round((completedCount / problems.length) * 100)}%</span>
              )}
            </div>
          </div>
          {!isWorksheetComplete && (
            <div className="mt-4 h-2 bg-slate-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-sky-500 transition-all duration-500"
                style={{ width: `${(completedCount / problems.length) * 100}%` }}
              />
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {problems.map((problem) => {
          const isCompleted = completedIds.has(problem.id);
          return (
            <Card
              key={problem.id}
              className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                isCompleted 
                  ? "border-emerald-300 bg-emerald-50/50" 
                  : "border-slate-200 bg-white hover:border-sky-300"
              }`}
              onClick={() => onSelectProblem(problem)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-base font-semibold text-slate-800 flex-1 pr-2">
                    {problem.question}
                  </CardTitle>
                  <div className="flex-shrink-0">
                    {isCompleted ? (
                      <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center">
                        <CheckCircle className="w-5 h-5 text-white" />
                      </div>
                    ) : (
                      <div className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center">
                        <Circle className="w-5 h-5 text-slate-400" />
                      </div>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-medium px-2 py-1 rounded-full border ${getDifficultyColor(problem.difficulty)}`}>
                    {problem.difficulty}
                  </span>
                  <span className="text-sm text-slate-500">
                    {problem.steps.length} steps
                  </span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {isWorksheetComplete && (
        <div className="mt-8 p-6 bg-emerald-50 border-2 border-emerald-200 rounded-xl text-center">
          <h3 className="text-xl font-bold text-emerald-800 mb-2">Worksheet Complete! 🎉</h3>
          <p className="text-emerald-700">You've mastered all problems in this topic.</p>
        </div>
      )}
    </div>
  );
}