import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Calculator, Atom, BookOpen } from "lucide-react";

interface TopicSelectorProps {
  subject: "maths" | "physics";
  topics: string[];
  onSelectTopic: (topic: string) => void;
}

export function TopicSelector({ subject, topics, onSelectTopic }: TopicSelectorProps) {
  const isMaths = subject === "maths";

  return (
    <div className="w-full max-w-5xl mx-auto p-8">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold text-slate-800 mb-3 flex items-center justify-center gap-3">
          {isMaths ? <Calculator className="w-10 h-10 text-sky-600" /> : <Atom className="w-10 h-10 text-indigo-600" />}
          {isMaths ? "Edexcel Maths" : "Edexcel Physics"}
        </h1>
        <p className="text-lg text-slate-600">
          Select a topic to start your step-by-step practice.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {topics.map((topic) => (
          <Card
            key={topic}
            className="group cursor-pointer hover:shadow-md transition-all duration-200 border-2 hover:border-sky-300 bg-white"
            onClick={() => onSelectTopic(topic)}
          >
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                  isMaths ? "bg-sky-100 text-sky-600" : "bg-indigo-100 text-indigo-600"
                }`}>
                  <BookOpen className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-800 text-lg group-hover:text-sky-700 transition-colors">
                    {topic}
                  </h3>
                  <p className="text-sm text-slate-500 mt-1">
                    Practice problems
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}