import { useEffect, useState } from "react";
import { Play, Pause } from "lucide-react";
import { Button } from "../components/ui/button";

interface TimerBarProps {
  isRunning: boolean;
  onToggle: () => void;
  onTimeUp: () => void;
}

export function TimerBar({ isRunning, onToggle, onTimeUp }: TimerBarProps) {
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            onTimeUp();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeLeft, onTimeUp]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const percentage = (timeLeft / 300) * 100;

  return (
    <div className="w-full bg-slate-100 rounded-full h-3 mb-6 overflow-hidden">
      <div 
        className="h-full bg-sky-500 transition-all duration-1000 ease-linear"
        style={{ width: `${percentage}%` }}
      />
      <div className="flex items-center justify-between mt-3">
        <span className="text-sm font-medium text-slate-600">
          {minutes}:{seconds.toString().padStart(2, "0")}
        </span>
        <Button
          onClick={onToggle}
          size="sm"
          variant="ghost"
          className="h-8 w-8 p-0 rounded-full hover:bg-sky-100"
        >
          {isRunning ? (
            <Pause className="w-4 h-4 text-sky-600" />
          ) : (
            <Play className="w-4 h-4 text-sky-600 ml-0.5" />
          )}
        </Button>
      </div>
    </div>
  );
}