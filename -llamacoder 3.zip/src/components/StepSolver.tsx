import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { TimerBar } from "./TimerBar";
import { ProgressTracker } from "./ProgressTracker";
import { ArrowRight, BookOpen } from "lucide-react";
import { MathProblem } from "../data/mathProblems";
import { saveProgress, loadProgress, SavedProgress, markProblemCompleted } from "../utils/localStorageHelper";

interface StepSolverProps {
  problem: MathProblem;
  onBack: () => void; // Changed: Now returns to worksheet
  onComplete: () => void;
}

export function StepSolver({ problem, onBack, onComplete }: StepSolverProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [timerRunning, setTimerRunning] = useState(true);

  useEffect(() => {
    const saved = loadProgress();
    if (saved.currentProblemId === problem.id) {
      setCurrentStep(saved.currentStep);
      setTimerRunning(false);
    }
  }, [problem.id]);

  useEffect(() => {
    const progress: SavedProgress = {
      currentProblemId: problem.id,
      currentStep,
      completedProblems: loadProgress().completedProblems,
      timerRemaining: 300
    };
    saveProgress(progress);
  }, [currentStep, problem.id]);

  const handleNextStep = () => {
    if (currentStep < problem.steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      // Mark problem as completed
      markProblemCompleted(problem.id);
      onComplete();
    }
  };

  const handleTimeUp = () => {
    setTimerRunning(false);
  };

  const getHighlightedEquation = (equation: string, highlight: string[]) => {
    let result = equation;
    highlight.forEach(term => {
      const regex = new RegExp(`(${term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'g');
      result = result.replace(regex, '<span class="bg-sky-200 text-sky-900 px-1.5 py-0.5 rounded font-bold">$1</span>');
    });
    return result;
  };

  return (
    <div className="w-full max-w-3xl mx-auto p-8">
      <TimerBar 
        isRunning={timerRunning} 
        onToggle={() => setTimerRunning(!timerRunning)}
        onTimeUp={handleTimeUp}
      />

      <Card className="bg-white border-slate-200 shadow-sm">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">{problem.topic}</p>
              <CardTitle className="flex items-center gap-2 text-slate-800 text-xl">
                <BookOpen className="w-5 h-5 text-sky-600" />
                Problem {problem.id.slice(-1)}
              </CardTitle>
            </div>
            <span className="text-sm px-3 py-1 rounded-full bg-slate-100 text-slate-600 font-medium">
              {problem.difficulty}
            </span>
          </div>
        </CardHeader>
        <CardContent className="space-y-8 pt-2">
          {/* Question Block */}
          <div className="p-6 bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl border-2 border-slate-200">
            <p className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-2">Problem</p>
            <p className="text-2xl font-bold text-slate-800 text-center font-mono">
              {problem.question}
            </p>
          </div>

          <ProgressTracker 
            totalSteps={problem.steps.length} 
            currentStep={currentStep + 1}
          />

          {/* Steps Container */}
          <div className="space-y-5">
            {problem.steps.slice(0, currentStep + 1).map((step, index) => (
              <div
                key={index}
                className={`group relative overflow-hidden rounded-2xl border-2 transition-all duration-300 ${
                  index === currentStep 
                    ? "bg-white border-sky-300 shadow-md" 
                    : "bg-slate-50 border-slate-200"
                }`}
              >
                {/* Step Header */}
                <div className={`flex items-center gap-4 p-5 pb-0 ${
                  index === currentStep ? "text-slate-800" : "text-slate-600"
                }`}>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-lg ${
                    index === currentStep 
                      ? "bg-sky-500 text-white shadow-sm" 
                      : "bg-emerald-500 text-white"
                  }`}>
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <p className="text-base font-medium leading-relaxed">
                      {step.explanation}
                    </p>
                  </div>
                </div>

                {/* Equation Block */}
                <div className="px-5 pb-5 pt-4">
                  <div className="ml-14 p-5 bg-slate-100 rounded-xl border border-slate-200">
                    <p 
                      className="text-xl md:text-2xl font-mono text-center text-slate-800 leading-relaxed tracking-wide"
                      dangerouslySetInnerHTML={{ 
                        __html: getHighlightedEquation(step.equation, step.highlight) 
                      }}
                    />
                  </div>
                </div>

                {/* Action Label */}
                <div className="px-5 pb-4 ml-14">
                  <span className={`inline-flex items-center gap-1.5 text-sm font-medium px-3 py-1 rounded-full ${
                    index === currentStep 
                      ? "bg-sky-100 text-sky-700" 
                      : "bg-emerald-100 text-emerald-700"
                  }`}>
                    {step.action}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation Buttons */}
          <div className="flex gap-3 pt-4 border-t border-slate-100">
            <Button
              onClick={onBack}
              variant="outline"
              className="flex-1 h-12 text-base border-slate-300 text-slate-700 hover:bg-slate-100 font-medium"
            >
              Back to Worksheet
            </Button>
            <Button
              onClick={handleNextStep}
              className="flex-1 h-12 text-base bg-sky-600 hover:bg-sky-700 text-white font-medium shadow-sm"
            >
              {currentStep < problem.steps.length - 1 ? (
                <>
                  Next Step
                  <ArrowRight className="w-5 h-5 ml-2" />
                </>
              ) : (
                "Complete Problem"
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}