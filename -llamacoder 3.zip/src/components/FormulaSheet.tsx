import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Sigma, X, ChevronUp, ChevronDown } from "lucide-react";

export function FormulaSheet() {
  const [isOpen, setIsOpen] = useState(false);

  const mathFormulas = [
    { name: "Quadratic Formula", formula: "x = (-b ± √(b²-4ac)) / 2a" },
    { name: "Pythagoras", formula: "a² + b² = c²" },
    { name: "Trigonometry", formula: "SOHCAHTOA" },
    { name: "Circle Area", formula: "A = πr²" },
    { name: "Circle Circumference", formula: "C = 2πr" }
  ];

  const physicsFormulas = [
    { name: "Speed", formula: "s = d ÷ t" },
    { name: "Acceleration", formula: "a = Δv ÷ t" },
    { name: "Force", formula: "F = m × a" },
    { name: "Weight", formula: "W = m × g" },
    { name: "Kinetic Energy", formula: "KE = ½mv²" },
    { name: "Ohm's Law", formula: "V = I × R" },
    { name: "Wave Speed", formula: "v = f × λ" }
  ];

  return (
    <div className="fixed bottom-6 right-24 z-40 flex flex-col items-end">
      {/* Toggle Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="mb-2 h-10 px-4 rounded-full shadow-md bg-amber-500 hover:bg-amber-600 text-white font-medium text-sm flex items-center gap-2"
      >
        <Sigma className="w-4 h-4" />
        Formula Sheet
        {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
      </Button>

      {/* Sheet Content */}
      {isOpen && (
        <Card className="w-72 shadow-xl border-amber-200 bg-amber-50">
          <CardHeader className="pb-3 bg-amber-100 border-b border-amber-200">
            <CardTitle className="text-amber-900 text-base">Quick Formulas</CardTitle>
          </CardHeader>
          <CardContent className="p-4 space-y-4 max-h-96 overflow-y-auto">
            <div>
              <h4 className="text-xs font-bold text-sky-700 uppercase tracking-wider mb-2">Maths</h4>
              <div className="space-y-2">
                {mathFormulas.map((f, i) => (
                  <div key={i} className="bg-white p-2 rounded border border-amber-100">
                    <p className="text-[10px] text-slate-500 font-medium">{f.name}</p>
                    <p className="text-sm font-mono font-semibold text-slate-800">{f.formula}</p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold text-indigo-700 uppercase tracking-wider mb-2">Physics</h4>
              <div className="space-y-2">
                {physicsFormulas.map((f, i) => (
                  <div key={i} className="bg-white p-2 rounded border border-amber-100">
                    <p className="text-[10px] text-slate-500 font-medium">{f.name}</p>
                    <p className="text-sm font-mono font-semibold text-slate-800">{f.formula}</p>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}