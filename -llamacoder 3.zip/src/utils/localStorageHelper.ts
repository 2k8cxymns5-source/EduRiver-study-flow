const STORAGE_KEY = "mathstep_progress";

export interface SavedProgress {
  currentProblemId: string | null;
  currentStep: number;
  completedProblems: string[]; // Array of completed problem IDs
  timerRemaining: number;
}

export function saveProgress(progress: SavedProgress): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (e) {
    console.warn("Could not save to localStorage:", e);
  }
}

export function loadProgress(): SavedProgress {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.warn("Could not load from localStorage:", e);
  }
  return {
    currentProblemId: null,
    currentStep: 0,
    completedProblems: [],
    timerRemaining: 300
  };
}

export function markProblemCompleted(problemId: string): void {
  const progress = loadProgress();
  if (!progress.completedProblems.includes(problemId)) {
    progress.completedProblems.push(problemId);
    saveProgress(progress);
  }
}

export function clearProgress(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.warn("Could not clear localStorage:", e);
  }
}