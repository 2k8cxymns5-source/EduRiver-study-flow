import { useState, useEffect, useRef } from "react"
import { Download, Upload, Trash2, Pencil, Eraser, Type, Save } from "lucide-react"
import { Button } from "./ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"

type Tool = "pen" | "eraser" | "text"
type Color = "black" | "gray" | "lime" | "blue"

interface Point {
  x: number
  y: number
}

interface Drawing {
  id: string
  paths: { points: Point[]; color: Color; width: number }[]
  texts: { x: number; y: number; text: string; color: Color }[]
  savedAt: string
}

export default function DrawPlan() {
  const [tool, setTool] = useState<Tool>("pen")
  const [color, setColor] = useState<Color>("black")
  const [penWidth, setPenWidth] = useState(2)
  const [isDrawing, setIsDrawing] = useState(false)
  const [currentPath, setCurrentPath] = useState<Point[]>([])
  const [paths, setPaths] = useState<{ points: Point[]; color: Color; width: number }[]>([])
  const [texts, setTexts] = useState<{ x: number; y: number; text: string; color: Color }[]>([])
  const [savedDrawings, setSavedDrawings] = useState<Drawing[]>([])
  const [textInput, setTextInput] = useState("")
  const [textPosition, setTextPosition] = useState<{ x: number; y: number } | null>(null)
  const [currentDrawingId, setCurrentDrawingId] = useState<string | null>(null)
  
  const canvasRef = useRef<HTMLDivElement>(null)

  const colors: Color[] = ["black", "gray", "lime", "blue"]
  const colorMap = {
    black: "bg-slate-800",
    gray: "bg-slate-400",
    lime: "bg-lime-500",
    blue: "bg-blue-500",
  }

  const strokeColorMap = {
    black: "#1e293b",
    gray: "#94a3b8",
    lime: "#84cc16",
    blue: "#3b82f6",
  }

  useEffect(() => {
    const saved = localStorage.getItem("focusflow-drawings")
    if (saved) {
      setSavedDrawings(JSON.parse(saved))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("focusflow-drawings", JSON.stringify(savedDrawings))
  }, [savedDrawings])

  const getPoint = (e: React.MouseEvent | React.TouchEvent): Point => {
    const rect = canvasRef.current?.getBoundingClientRect()
    if (!rect) return { x: 0, y: 0 }
    
    const clientX = "touches" in e ? e.touches[0].clientX : e.clientX
    const clientY = "touches" in e ? e.touches[0].clientY : e.clientY
    
    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    }
  }

  const handleStart = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault()
    
    if (tool === "text") {
      const point = getPoint(e)
      setTextPosition(point)
      setTextInput("")
      return
    }

    setIsDrawing(true)
    setCurrentPath([getPoint(e)])
  }

  const handleMove = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault()
    
    if (!isDrawing || tool === "text") return
    
    setCurrentPath([...currentPath, getPoint(e)])
  }

  const handleEnd = () => {
    if (!isDrawing) return
    
    if (currentPath.length > 1) {
      setPaths([...paths, { points: currentPath, color, width: penWidth }])
    }
    
    setIsDrawing(false)
    setCurrentPath([])
  }

  const addText = () => {
    if (textPosition && textInput.trim()) {
      setTexts([...texts, { ...textPosition, text: textInput, color }])
      setTextPosition(null)
      setTextInput("")
    }
  }

  const clearCanvas = () => {
    setPaths([])
    setTexts([])
  }

  const saveDrawing = () => {
    const drawing: Drawing = {
      id: currentDrawingId || Date.now().toString(),
      paths,
      texts,
      savedAt: new Date().toISOString(),
    }
    
    setSavedDrawings(prev => {
      const filtered = prev.filter(d => d.id !== drawing.id)
      return [drawing, ...filtered]
    })
    setCurrentDrawingId(drawing.id)
  }

  const loadDrawing = (drawing: Drawing) => {
    setPaths(drawing.paths)
    setTexts(drawing.texts)
    setCurrentDrawingId(drawing.id)
  }

  const exportAsPNG = () => {
    const svg = canvasRef.current?.querySelector("svg")
    if (!svg) return

    const svgData = new XMLSerializer().serializeToString(svg)
    const canvas = document.createElement("canvas")
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const img = new Image()
    img.onload = () => {
      canvas.width = 800
      canvas.height = 600
      ctx.fillStyle = "white"
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      ctx.drawImage(img, 0, 0)
      
      const link = document.createElement("a")
      link.download = `focusflow-sketch-${Date.now()}.png`
      link.href = canvas.toDataURL("image/png")
      link.click()
    }
    img.src = "data:image/svg+xml;base64," + btoa(svgData)
  }

  const createNewDrawing = () => {
    clearCanvas()
    setCurrentDrawingId(null)
  }

  const renderPath = (points: Point[], color: Color, width: number) => {
    if (points.length < 2) return null
    
    const pathD = points.reduce((acc, point, index) => {
      if (index === 0) return `M ${point.x} ${point.y}`
      return `${acc} L ${point.x} ${point.y}`
    }, "")

    return (
      <path
        d={pathD}
        stroke={strokeColorMap[color]}
        strokeWidth={width}
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>DrawPlan Hub</CardTitle>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={createNewDrawing}>
            New
          </Button>
          <Button variant="outline" size="sm" onClick={saveDrawing}>
            <Save className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={exportAsPNG}>
            <Download className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-4 gap-4">
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium mb-2">Tools</p>
              <div className="flex gap-2">
                <Button
                  variant={tool === "pen" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTool("pen")}
                >
                  <Pencil className="w-4 h-4" />
                </Button>
                <Button
                  variant={tool === "eraser" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTool("eraser")}
                >
                  <Eraser className="w-4 h-4" />
                </Button>
                <Button
                  variant={tool === "text" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTool("text")}
                >
                  <Type className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {tool === "pen" && (
              <div>
                <p className="text-sm font-medium mb-2">Pen Size</p>
                <div className="flex gap-2">
                  {[1, 2, 3].map(size => (
                    <Button
                      key={size}
                      variant={penWidth === size ? "default" : "outline"}
                      size="sm"
                      onClick={() => setPenWidth(size)}
                      className="w-10"
                    >
                      {size}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            <div>
              <p className="text-sm font-medium mb-2">Colors</p>
              <div className="flex gap-2">
                {colors.map(c => (
                  <button
                    key={c}
                    onClick={() => setColor(c)}
                    className={`w-8 h-8 rounded-full ${colorMap[c]} border-2 ${color === c ? "border-slate-800 scale-110" : "border-transparent"}`}
                  />
                ))}
              </div>
            </div>

            <Button variant="destructive" size="sm" onClick={clearCanvas} className="w-full">
              <Trash2 className="w-4 h-4 mr-2" />
              Clear Canvas
            </Button>

            <div>
              <p className="text-sm font-medium mb-2">Saved Sketches</p>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {savedDrawings.map(drawing => (
                  <div
                    key={drawing.id}
                    onClick={() => loadDrawing(drawing)}
                    className={`p-2 rounded cursor-pointer text-sm border-2 ${
                      currentDrawingId === drawing.id
                        ? "bg-lime-500 text-white border-lime-500"
                        : "bg-white border-lime-200 hover:border-lime-400"
                    }`}
                  >
                    {new Date(drawing.savedAt).toLocaleDateString()}
                  </div>
                ))}
                {savedDrawings.length === 0 && (
                  <p className="text-sm text-slate-500">No saved sketches</p>
                )}
              </div>
            </div>
          </div>

          <div className="md:col-span-3">
            <div className="bg-white border-2 border-lime-200 rounded-lg overflow-hidden">
              <div
                ref={canvasRef}
                className="w-full h-96 relative cursor-crosshair"
                onMouseDown={handleStart}
                onMouseMove={handleMove}
                onMouseUp={handleEnd}
                onMouseLeave={handleEnd}
                onTouchStart={handleStart}
                onTouchMove={handleMove}
                onTouchEnd={handleEnd}
              >
                <svg className="w-full h-full">
                  {paths.map((path, index) => (
                    <g key={index}>
                      {renderPath(path.points, path.color, path.width)}
                    </g>
                  ))}
                  {currentPath.length > 1 && renderPath(currentPath, color, penWidth)}
                  {texts.map((text, index) => (
                    <text
                      key={index}
                      x={text.x}
                      y={text.y}
                      fill={strokeColorMap[text.color]}
                      fontSize="16"
                      fontFamily="sans-serif"
                    >
                      {text.text}
                    </text>
                  ))}
                </svg>

                {textPosition && (
                  <div
                    className="absolute bg-white border-2 border-lime-500 p-2 rounded shadow-lg"
                    style={{ left: textPosition.x, top: textPosition.y }}
                  >
                    <Input
                      value={textInput}
                      onChange={(e) => setTextInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && addText()}
                      onBlur={addText}
                      placeholder="Type note..."
                      autoFocus
                      className="w-48"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}