import { useState, useEffect, useRef } from "react"
import { Send, MessageSquare, ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"

interface Message {
  id: string
  role: "user" | "assistant"
  text: string
  timestamp: string
}

const focusResponses = [
  "Try one task at a time. What's the smallest step you can take right now?",
  "You've got this! Focus on just one thing for the next 5 minutes.",
  "Take a deep breath. What's the most important thing on your list?",
  "Remember: progress over perfection. Even small steps count!",
  "Feeling overwhelmed? Let's break it down. What's one tiny action you can take?",
  "Great job checking in! What would make you feel accomplished today?",
  "You've focused for a while. Time for a 5-minute stretch?",
  "What's one thing you want to remember from this session?",
  "Trust the process. You're doing better than you think!",
  "Let's reset. What's your main priority right now?",
]

const greetingResponses = [
  "Hi there! I'm here to help you stay focused. Type @focus whenever you need a gentle nudge.",
  "Hello! Ready to tackle your tasks? Remember, small steps lead to big progress.",
  "Hey! How can I help you flow today? Use @focus for encouragement.",
]

const defaultResponses = [
  "I'm a simple assistant focused on helping you stay on track. Try typing @focus for encouragement!",
  "I'm here to support your focus journey. What task are you working on?",
  "Remember to take breaks and be kind to yourself. Type @focus for a reminder!",
]

export default function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isHistoryOpen, setIsHistoryOpen] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const saved = localStorage.getItem("focusflow-chat")
    if (saved) {
      setMessages(JSON.parse(saved))
    } else {
      // Add welcome message
      const welcome: Message = {
        id: Date.now().toString(),
        role: "assistant",
        text: greetingResponses[Math.floor(Math.random() * greetingResponses.length)],
        timestamp: new Date().toISOString(),
      }
      setMessages([welcome])
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("focusflow-chat", JSON.stringify(messages))
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const generateResponse = (userInput: string): string => {
    const lowerInput = userInput.toLowerCase().trim()

    if (lowerInput.includes("@focus")) {
      return focusResponses[Math.floor(Math.random() * focusResponses.length)]
    }

    if (lowerInput.includes("hello") || lowerInput.includes("hi") || lowerInput.includes("hey")) {
      return greetingResponses[Math.floor(Math.random() * greetingResponses.length)]
    }

    if (lowerInput.includes("help")) {
      return "I'm here to help! Type @focus for encouragement, or tell me what you're working on."
    }

    if (lowerInput.includes("overwhelm") || lowerInput.includes("stuck") || lowerInput.includes("hard")) {
      return "It's okay to feel overwhelmed. Let's take it one small step at a time. What's the tiniest action you could take right now?"
    }

    if (lowerInput.includes("done") || lowerInput.includes("finish") || lowerInput.includes("complete")) {
      return "Amazing! Celebrate that win, no matter how small. Ready for the next challenge?"
    }

    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)]
  }

  const sendMessage = () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      text: input,
      timestamp: new Date().toISOString(),
    }

    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: "assistant",
      text: generateResponse(input),
      timestamp: new Date().toISOString(),
    }

    setMessages([...messages, userMessage, assistantMessage])
    setInput("")
  }

  const clearHistory = () => {
    setMessages([])
    localStorage.removeItem("focusflow-chat")
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-lime-600" />
          AI Assistant
        </CardTitle>
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsHistoryOpen(!isHistoryOpen)}
          >
            {isHistoryOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearHistory}
            className="text-red-500 hover:text-red-700"
          >
            Clear
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isHistoryOpen && (
          <div className="space-y-4 mb-4 max-h-96 overflow-y-auto">
            {messages.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <p>No messages yet. Start a conversation!</p>
              </div>
            ) : (
              messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-xs md:max-w-md px-4 py-2 rounded-2xl ${
                      message.role === "user"
                        ? "bg-lime-500 text-white rounded-br-sm"
                        : "bg-white border-2 border-lime-200 rounded-bl-sm"
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                    <p className="text-xs mt-1 opacity-60">
                      {new Date(message.timestamp).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>
        )}

        <div className="flex gap-2">
          <Input
            placeholder="Type @focus for encouragement..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          />
          <Button onClick={sendMessage}>
            <Send className="w-4 h-4" />
          </Button>
        </div>

        <div className="mt-4 p-3 bg-lime-50 border border-lime-200 rounded-lg">
          <p className="text-sm text-slate-600">
            <strong>Tip:</strong> Type <span className="font-mono bg-lime-200 px-1 rounded">@focus</span> for gentle encouragement and focus tips!
          </p>
        </div>
      </CardContent>
    </Card>
  )
}