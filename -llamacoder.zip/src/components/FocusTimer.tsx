import { useState, useEffect, useRef } from "react"
import { Play, Pause, RotateCcw, Settings } from "lucide-react"
import { Button } from "./ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"
import { Label } from "./ui/label"

interface FocusTimerProps {
  setIsFocusMode: (value: boolean) => void
}

export default function FocusTimer({ setIsFocusMode }: FocusTimerProps) {
  const [minutes, setMinutes] = useState(25)
  const [seconds, setSeconds] = useState(0)
  const [isRunning, setIsRunning] = useState(false)
  const [isBreak, setIsBreak] = useState(false)
  const [focusDuration, setFocusDuration] = useState(25)
  const [breakDuration, setBreakDuration] = useState(5)
  const [showSettings, setShowSettings] = useState(false)
  const audioContextRef = useRef<AudioContext | null>(null)

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isRunning) {
      setIsFocusMode(true)
      interval = setInterval(() => {
        if (seconds === 0) {
          if (minutes === 0) {
            // Timer finished
            playAlarm()
            setIsRunning(false)
            setIsFocusMode(false)
            
            if (!isBreak) {
              // Switch to break
              setIsBreak(true)
              setMinutes(breakDuration)
              setSeconds(0)
            } else {
              // Switch back to focus
              setIsBreak(false)
              setMinutes(focusDuration)
              setSeconds(0)
            }
          } else {
            setMinutes(minutes - 1)
            setSeconds(59)
          }
        } else {
          setSeconds(seconds - 1)
        }
      }, 1000)
    } else {
      setIsFocusMode(false)
    }

    return () => clearInterval(interval)
  }, [isRunning, minutes, seconds, isBreak, focusDuration, breakDuration, setIsFocusMode])

  const playAlarm = () => {
    // Create gentle chime using Web Audio API
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    audioContextRef.current = audioContext

    const playTone = (freq: number, startTime: number, duration: number) => {
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()
      
      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)
      
      oscillator.frequency.value = freq
      oscillator.type = "sine"
      
      gainNode.gain.setValueAtTime(0, startTime)
      gainNode.gain.linearRampToValueAtTime(0.3, startTime + 0.1)
      gainNode.gain.linearRampToValueAtTime(0, startTime + duration)
      
      oscillator.start(startTime)
      oscillator.stop(startTime + duration)
    }

    const now = audioContext.currentTime
    playTone(523.25, now, 0.5) // C5
    playTone(659.25, now + 0.3, 0.5) // E5
    playTone(783.99, now + 0.6, 0.8) // G5
  }

  const toggleTimer = () => {
    setIsRunning(!isRunning)
  }

  const resetTimer = () => {
    setIsRunning(false)
    setIsBreak(false)
    setMinutes(focusDuration)
    setSeconds(0)
    setIsFocusMode(false)
  }

  const formatTime = (mins: number, secs: number) => {
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const progress = isBreak 
    ? ((breakDuration * 60 - (minutes * 60 + seconds)) / (breakDuration * 60)) * 100
    : ((focusDuration * 60 - (minutes * 60 + seconds)) / (focusDuration * 60)) * 100

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>{isBreak ? "Break Time" : "Focus Timer"}</CardTitle>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowSettings(!showSettings)}
        >
          <Settings className="w-4 h-4" />
        </Button>
      </CardHeader>
      <CardContent>
        {showSettings && (
          <div className="mb-6 p-4 bg-white rounded-lg border-2 border-lime-200 space-y-4">
            <div>
              <Label>Focus Duration (minutes)</Label>
              <Input
                type="number"
                value={focusDuration}
                onChange={(e) => setFocusDuration(Math.max(1, parseInt(e.target.value) || 25))}
                min="1"
                max="120"
              />
            </div>
            <div>
              <Label>Break Duration (minutes)</Label>
              <Input
                type="number"
                value={breakDuration}
                onChange={(e) => setBreakDuration(Math.max(1, parseInt(e.target.value) || 5))}
                min="1"
                max="30"
              />
            </div>
          </div>
        )}

        <div className="text-center py-8">
          <div className="text-8xl font-bold mb-4 font-mono">
            {formatTime(minutes, seconds)}
          </div>
          
          <div className="w-full bg-slate-200 rounded-full h-4 mb-6 overflow-hidden">
            <div
              className={`h-full transition-all duration-1000 ${isBreak ? "bg-blue-500" : "bg-lime-500"}`}
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="flex justify-center gap-4">
            <Button
              size="lg"
              onClick={toggleTimer}
              className={isRunning ? "bg-yellow-500 hover:bg-yellow-600" : "bg-lime-500 hover:bg-lime-600"}
            >
              {isRunning ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={resetTimer}
            >
              <RotateCcw className="w-6 h-6" />
            </Button>
          </div>

          <p className="mt-6 text-slate-600">
            {isRunning 
              ? isBreak ? "Take a deep breath and relax" : "Stay focused, you're doing great!"
              : "Press play to start your session"
            }
          </p>
        </div>
      </CardContent>
    </Card>
  )
}