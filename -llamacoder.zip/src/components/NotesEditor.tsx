import { useState, useEffect } from "react"
import { Save, Tag, Moon, Sun } from "lucide-react"
import { Button } from "./ui/button"
import { Textarea } from "./ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"

interface Note {
  id: string
  content: string
  tags: string[]
  updatedAt: string
}

export default function NotesEditor() {
  const [content, setContent] = useState("")
  const [tags, setTags] = useState<string[]>([])
  const [tagInput, setTagInput] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [savedNotes, setSavedNotes] = useState<Note[]>([])
  const [currentNoteId, setCurrentNoteId] = useState<string | null>(null)
  const [isDarkMode, setIsDarkMode] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem("focusflow-notes")
    if (saved) {
      setSavedNotes(JSON.parse(saved))
    }
    
    const darkMode = localStorage.getItem("focusflow-darkmode")
    if (darkMode === "true") {
      setIsDarkMode(true)
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("focusflow-notes", JSON.stringify(savedNotes))
  }, [savedNotes])

  useEffect(() => {
    localStorage.setItem("focusflow-darkmode", String(isDarkMode))
  }, [isDarkMode])

  // Auto-save current note
  useEffect(() => {
    if (content.trim() || tags.length > 0) {
      const note: Note = {
        id: currentNoteId || Date.now().toString(),
        content,
        tags,
        updatedAt: new Date().toISOString(),
      }
      
      setSavedNotes(prev => {
        const filtered = prev.filter(n => n.id !== note.id)
        return [note, ...filtered]
      })
      setCurrentNoteId(note.id)
    }
  }, [content, tags, currentNoteId])

  const addTag = () => {
    const tag = tagInput.trim().toLowerCase()
    if (tag && !tags.includes(tag)) {
      setTags([...tags, tag.startsWith("#") ? tag : `#${tag}`])
    }
    setTagInput("")
  }

  const removeTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag))
  }

  const loadNote = (note: Note) => {
    setContent(note.content)
    setTags(note.tags)
    setCurrentNoteId(note.id)
  }

  const createNewNote = () => {
    setContent("")
    setTags([])
    setCurrentNoteId(null)
  }

  const formatContent = (text: string) => {
    // Simple markdown-like formatting
    return text
      .replace(/^### (.*$)/gim, "<h3 class='text-lg font-bold mt-4 mb-2'>$1</h3>")
      .replace(/^## (.*$)/gim, "<h2 class='text-xl font-bold mt-4 mb-2'>$1</h2>")
      .replace(/^# (.*$)/gim, "<h1 class='text-2xl font-bold mt-4 mb-2'>$1</h1>")
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.*?)\*/g, "<em>$1</em>")
      .replace(/^- (.*$)/gim, "<li class='ml-4'>$1</li>")
      .replace(/\n/g, "<br />")
  }

  const filteredNotes = savedNotes.filter(note => {
    const matchesSearch = note.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    return matchesSearch
  })

  return (
    <div className={isDarkMode ? "bg-lime-900 text-lime-50" : ""}>
      <Card className={isDarkMode ? "bg-lime-800 border-lime-700" : ""}>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Study Notes</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsDarkMode(!isDarkMode)}
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="md:col-span-2 space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Add tags (e.g., #focus, #math)"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && addTag()}
                  className={isDarkMode ? "bg-lime-700 border-lime-600 text-lime-50" : ""}
                />
                <Button onClick={addTag}>
                  <Tag className="w-4 h-4" />
                </Button>
              </div>

              <div className="flex flex-wrap gap-2">
                {tags.map(tag => (
                  <span
                    key={tag}
                    className="px-3 py-1 bg-lime-500 text-white rounded-full text-sm flex items-center gap-2 cursor-pointer hover:bg-lime-600"
                    onClick={() => removeTag(tag)}
                  >
                    {tag}
                    <span className="text-xs">×</span>
                  </span>
                ))}
              </div>

              <Textarea
                placeholder="Start writing your notes... Use **bold**, *italic*, # headings, or - for bullets"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className={`min-h-96 font-mono text-sm ${isDarkMode ? "bg-lime-700 border-lime-600 text-lime-50" : ""}`}
              />

              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-500">
                  Auto-saved {savedNotes.length > 0 ? "just now" : ""}
                </span>
                <Button onClick={createNewNote} variant="outline">
                  New Note
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              <Input
                placeholder="Search notes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={isDarkMode ? "bg-lime-700 border-lime-600 text-lime-50" : ""}
              />

              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredNotes.map(note => (
                  <div
                    key={note.id}
                    onClick={() => loadNote(note)}
                    className={`p-3 rounded-lg cursor-pointer transition-all border-2 ${
                      currentNoteId === note.id
                        ? "bg-lime-500 text-white border-lime-500"
                        : isDarkMode
                        ? "bg-lime-700 border-lime-600 hover:bg-lime-600"
                        : "bg-white border-lime-200 hover:border-lime-400"
                    }`}
                  >
                    <div className="flex flex-wrap gap-1 mb-2">
                      {note.tags.slice(0, 3).map(tag => (
                        <span key={tag} className="text-xs opacity-80">
                          {tag}
                        </span>
                      ))}
                    </div>
                    <p className="text-sm line-clamp-3">
                      {note.content.slice(0, 100)}
                      {note.content.length > 100 ? "..." : ""}
                    </p>
                    <p className="text-xs mt-2 opacity-60">
                      {new Date(note.updatedAt).toLocaleDateString()}
                    </p>
                  </div>
                ))}

                {filteredNotes.length === 0 && (
                  <div className="text-center py-8 text-slate-500">
                    <p>No notes found</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}