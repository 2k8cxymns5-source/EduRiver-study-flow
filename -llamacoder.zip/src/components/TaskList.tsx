import { useState, useEffect } from "react"
import { Plus, Trash2, Check, GripVertical, Calendar } from "lucide-react"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select"

type Priority = "urgent" | "medium" | "low"
type Recurrence = "none" | "daily" | "weekly"

interface Task {
  id: string
  text: string
  priority: Priority
  dueDate: string
  recurrence: Recurrence
  completed: boolean
}

interface TaskListProps {
  showNotification: (message: string) => void
}

export default function TaskList({ showNotification }: TaskListProps) {
  const [tasks, setTasks] = useState<Task[]>([])
  const [newTask, setNewTask] = useState("")
  const [newPriority, setNewPriority] = useState<Priority>("medium")
  const [newDueDate, setNewDueDate] = useState("")
  const [newRecurrence, setNewRecurrence] = useState<Recurrence>("none")

  useEffect(() => {
    const saved = localStorage.getItem("focusflow-tasks")
    if (saved) {
      setTasks(JSON.parse(saved))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("focusflow-tasks", JSON.stringify(tasks))
    
    // Check for overdue tasks
    const today = new Date().toISOString().split("T")[0]
    tasks.forEach(task => {
      if (!task.completed && task.dueDate && task.dueDate < today) {
        showNotification(`Task overdue: ${task.text}`)
      }
    })
  }, [tasks, showNotification])

  const addTask = () => {
    if (!newTask.trim()) return
    
    const task: Task = {
      id: Date.now().toString(),
      text: newTask,
      priority: newPriority,
      dueDate: newDueDate,
      recurrence: newRecurrence,
      completed: false,
    }
    
    setTasks([...tasks, task])
    setNewTask("")
    setNewDueDate("")
    setNewRecurrence("none")
  }

  const toggleComplete = (id: string) => {
    setTasks(tasks.map(task => {
      if (task.id === id) {
        const updated = { ...task, completed: !task.completed }
        
        // Handle recurring tasks
        if (updated.completed && task.recurrence !== "none") {
          const newTask: Task = {
            ...task,
            id: Date.now().toString(),
            completed: false,
            dueDate: getNextDueDate(task.recurrence),
          }
          setTimeout(() => {
            setTasks(prev => [...prev, newTask])
          }, 100)
        }
        
        return updated
      }
      return task
    }))
  }

  const getNextDueDate = (recurrence: Recurrence): string => {
    const date = new Date()
    if (recurrence === "daily") {
      date.setDate(date.getDate() + 1)
    } else if (recurrence === "weekly") {
      date.setDate(date.getDate() + 7)
    }
    return date.toISOString().split("T")[0]
  }

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(task => task.id !== id))
  }

  const moveTask = (index: number, direction: "up" | "down") => {
    const newTasks = [...tasks]
    if (direction === "up" && index > 0) {
      [newTasks[index - 1], newTasks[index]] = [newTasks[index], newTasks[index - 1]]
    } else if (direction === "down" && index < tasks.length - 1) {
      [newTasks[index], newTasks[index + 1]] = [newTasks[index + 1], newTasks[index]]
    }
    setTasks(newTasks)
  }

  const getPriorityColor = (priority: Priority) => {
    switch (priority) {
      case "urgent": return "bg-red-500 text-white"
      case "medium": return "bg-yellow-500 text-white"
      case "low": return "bg-green-500 text-white"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Task Management</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-6 flex-wrap">
          <Input
            placeholder="Add a new task..."
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addTask()}
            className="flex-1 min-w-48"
          />
          <Select value={newPriority} onValueChange={(v: Priority) => setNewPriority(v)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="urgent">Urgent</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
          <Input
            type="date"
            value={newDueDate}
            onChange={(e) => setNewDueDate(e.target.value)}
            className="w-40"
          />
          <Select value={newRecurrence} onValueChange={(v: Recurrence) => setNewRecurrence(v)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">No repeat</SelectItem>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={addTask}>
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-2">
          {tasks.map((task, index) => (
            <div
              key={task.id}
              className={`flex items-center gap-3 p-3 rounded-lg border-2 transition-all ${
                task.completed ? "bg-slate-100 border-slate-200 opacity-60" : "bg-white border-lime-200"
              }`}
            >
              <Button
                variant="ghost"
                size="sm"
                onClick={() => moveTask(index, "up")}
                disabled={index === 0}
                className="opacity-50 hover:opacity-100"
              >
                <GripVertical className="w-4 h-4" />
              </Button>
              
              <Button
                variant={task.completed ? "default" : "outline"}
                size="sm"
                onClick={() => toggleComplete(task.id)}
                className={task.completed ? "bg-green-500 hover:bg-green-600" : ""}
              >
                <Check className="w-4 h-4" />
              </Button>

              <span className={`flex-1 ${task.completed ? "line-through" : ""}`}>
                {task.text}
              </span>

              <Badge className={getPriorityColor(task.priority)}>
                {task.priority}
              </Badge>

              {task.dueDate && (
                <div className="flex items-center gap-1 text-sm text-slate-600">
                  <Calendar className="w-4 h-4" />
                  {task.dueDate}
                </div>
              )}

              {task.recurrence !== "none" && (
                <Badge variant="outline">{task.recurrence}</Badge>
              )}

              <Button
                variant="ghost"
                size="sm"
                onClick={() => deleteTask(task.id)}
                className="text-red-500 hover:text-red-700 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}

          {tasks.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <p>No tasks yet. Add one above to get started!</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}