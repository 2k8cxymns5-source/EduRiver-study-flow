import { useState, useEffect } from "react"
import { CheckSquare, Clock, FileText, Palette, MessageSquare } from "lucide-react"
import { Button } from "./components/ui/button"
import TaskList from "./components/TaskList"
import FocusTimer from "./components/FocusTimer"
import NotesEditor from "./components/NotesEditor"
import DrawPlan from "./components/DrawPlan"
import AIAssistant from "./components/AIAssistant"

type Tab = "tasks" | "timer" | "notes" | "draw" | "ai"

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("tasks")
  const [isFocusMode, setIsFocusMode] = useState(false)
  const [notification, setNotification] = useState<string | null>(null)

  const tabs = [
    { id: "tasks" as Tab, icon: CheckSquare, label: "Tasks" },
    { id: "timer" as Tab, icon: Clock, label: "Timer" },
    { id: "notes" as Tab, icon: FileText, label: "Notes" },
    { id: "draw" as Tab, icon: Palette, label: "Draw" },
    { id: "ai" as Tab, icon: MessageSquare, label: "AI" },
  ]

  useEffect(() => {
    let idleTimer: NodeJS.Timeout
    const resetIdleTimer = () => {
      clearTimeout(idleTimer)
      if (isFocusMode) {
        idleTimer = setTimeout(() => {
          // Auto-hide UI in focus mode
        }, 10000)
      }
    }

    window.addEventListener("mousemove", resetIdleTimer)
    window.addEventListener("keydown", resetIdleTimer)
    resetIdleTimer()

    return () => {
      clearTimeout(idleTimer)
      window.removeEventListener("mousemove", resetIdleTimer)
      window.removeEventListener("keydown", resetIdleTimer)
    }
  }, [isFocusMode])

  const showNotification = (message: string) => {
    setNotification(message)
    setTimeout(() => setNotification(null), 5000)
  }

  return (
    <div className="min-h-screen bg-lime-100 text-slate-800">
      {notification && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 bg-white px-6 py-3 rounded-lg shadow-lg z-50 animate-in slide-in-from-top">
          {notification}
        </div>
      )}

      <div className="container mx-auto p-4 max-w-6xl">
        <header className="mb-6">
          <h1 className="text-3xl font-bold mb-2">FocusFlow</h1>
          <p className="text-slate-600">ADHD Workflow Hub</p>
        </header>

        <nav className={`flex gap-2 mb-6 flex-wrap transition-opacity ${isFocusMode ? "opacity-0" : "opacity-100"}`}>
          {tabs.map((tab) => (
            <Button
              key={tab.id}
              variant={activeTab === tab.id ? "default" : "outline"}
              onClick={() => setActiveTab(tab.id)}
              className="flex items-center gap-2"
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </Button>
          ))}
        </nav>

        <main>
          {activeTab === "tasks" && <TaskList showNotification={showNotification} />}
          {activeTab === "timer" && <FocusTimer setIsFocusMode={setIsFocusMode} />}
          {activeTab === "notes" && <NotesEditor />}
          {activeTab === "draw" && <DrawPlan />}
          {activeTab === "ai" && <AIAssistant />}
        </main>
      </div>
    </div>
  )
}